import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "read": True,
  "write": True,
  "link": True,
  "manage": False
}

response = requests.get(
    'https://api-sandbox.oftrust.net/acl/v1/{target_identity}/{permissions}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
