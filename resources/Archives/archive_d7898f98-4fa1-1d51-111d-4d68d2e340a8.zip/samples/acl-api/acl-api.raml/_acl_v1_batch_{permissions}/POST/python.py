import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "targets": [
    "82440763-b208-4eab-bc13-1f2620184ea1",
    "fed4bd28-fca4-4287-9389-b87dd77b815c",
    "e45f1815-167f-4348-b194-64cd01b5c52f",
    "016dfc04-4f4a-499c-a289-7861df876392",
    "3e0d7600-2a81-4be1-842e-81e14739e52c"
  ]
}

response = requests.post(
    'https://api-sandbox.oftrust.net/acl/v1/batch/{permissions}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
