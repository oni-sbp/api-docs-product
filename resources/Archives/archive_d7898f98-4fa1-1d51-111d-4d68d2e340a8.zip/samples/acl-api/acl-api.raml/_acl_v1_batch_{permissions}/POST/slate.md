```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "targets": [
    "82440763-b208-4eab-bc13-1f2620184ea1",
    "fed4bd28-fca4-4287-9389-b87dd77b815c",
    "e45f1815-167f-4348-b194-64cd01b5c52f",
    "016dfc04-4f4a-499c-a289-7861df876392",
    "3e0d7600-2a81-4be1-842e-81e14739e52c"
  ]
}

response = requests.post(
    'https://api-sandbox.oftrust.net/acl/v1/batch/{permissions}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X POST \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
   -H "Content-Type: application/json" \
   -d \
"{
  \"targets\": [
    \"82440763-b208-4eab-bc13-1f2620184ea1\",
    \"fed4bd28-fca4-4287-9389-b87dd77b815c\",
    \"e45f1815-167f-4348-b194-64cd01b5c52f\",
    \"016dfc04-4f4a-499c-a289-7861df876392\",
    \"3e0d7600-2a81-4be1-842e-81e14739e52c\"
  ]
}" "https://api-sandbox.oftrust.net/acl/v1/batch/{permissions}"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "targets": [
    "82440763-b208-4eab-bc13-1f2620184ea1",
    "fed4bd28-fca4-4287-9389-b87dd77b815c",
    "e45f1815-167f-4348-b194-64cd01b5c52f",
    "016dfc04-4f4a-499c-a289-7861df876392",
    "3e0d7600-2a81-4be1-842e-81e14739e52c"
  ]
}; 

unirest
  .post("https://api-sandbox.oftrust.net/acl/v1/batch/{permissions}")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "82440763-b208-4eab-bc13-1f2620184ea1": true,
  "fed4bd28-fca4-4287-9389-b87dd77b815c": false,
  "e45f1815-167f-4348-b194-64cd01b5c52f": true,
  "016dfc04-4f4a-499c-a289-7861df876392": true,
  "3e0d7600-2a81-4be1-842e-81e14739e52c": false
}

```
