const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "read": true,
  "write": true,
  "link": true,
  "manage": false
}; 

unirest
  .post("https://api-sandbox.oftrust.net/acl/v1/{from_identity}/{target_identity}")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });