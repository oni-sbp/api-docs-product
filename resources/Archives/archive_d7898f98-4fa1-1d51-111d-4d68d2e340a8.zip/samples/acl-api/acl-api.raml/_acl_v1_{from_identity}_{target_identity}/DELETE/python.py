import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "read": True,
  "write": True,
  "link": True,
  "manage": False
}

response = requests.delete(
    'https://api-sandbox.oftrust.net/acl/v1/{from_identity}/{target_identity}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
