```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "dataContext": "https://example.com/v1/Context/Data",
  "parameterContext": "https://example.com/v1/Context/Parameter",
  "productCode": "product-1",
  "name": "Product name",
  "translatorUrl": "https://example.com/translator",
  "organizationPublicKeys": [
    {
      "url": "https://example.com/public-key.pub",
      "type": "RsaSignature2018"
    },
    {
      "url": "https://example.com/public-key-2.pub",
      "type": "RsaSignature2018"
    }
  ],
  "imageUrl": "https://example.com/product-image.png",
  "description": "This is a product that returns the temperature data for ..."
}

response = requests.delete(
    'https://api-sandbox.oftrust.net/products/{version}/{product_code}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X DELETE \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
 "https://api-sandbox.oftrust.net/products/{version}/{product_code}"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .delete("https://api-sandbox.oftrust.net/products/{version}/{product_code}")
  .headers(headers)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 204

{}

```
