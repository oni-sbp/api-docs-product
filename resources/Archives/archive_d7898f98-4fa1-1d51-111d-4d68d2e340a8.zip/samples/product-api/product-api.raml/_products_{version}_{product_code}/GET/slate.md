```python
import requests

body = {
  "dataContext": "https://example.com/v1/Context/Data",
  "parameterContext": "https://example.com/v1/Context/Parameter",
  "productCode": "product-1",
  "name": "Product name",
  "translatorUrl": "https://example.com/translator",
  "organizationPublicKeys": [
    {
      "url": "https://example.com/public-key.pub",
      "type": "RsaSignature2018"
    },
    {
      "url": "https://example.com/public-key-2.pub",
      "type": "RsaSignature2018"
    }
  ],
  "imageUrl": "https://example.com/product-image.png",
  "description": "This is a product that returns the temperature data for ...",
  "groupId": "0a52c776-1c9c-42b1-ac03-b64c04abded2"
}

response = requests.get(
    'https://api-sandbox.oftrust.net/products/{version}/{product_code}',
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X GET \
 "https://api-sandbox.oftrust.net/products/{version}/{product_code}"

```

```javascript
const unirest = require("unirest");


unirest
  .get("https://api-sandbox.oftrust.net/products/{version}/{product_code}")
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "@context": "https://standards.lifeengine.io/v1/Context/Identity/Thing/HumanWorld/Product/DataProduct",
  "@type": "DataProduct",
  "@id": "https://api-sandbox.oftrust.net/products/v1/product-1",
  "productCode": "product-1",
  "dataContext": "https://example.com/v1/Context/Data",
  "parameterContext": "https://example.com/v1/Context/Parameter",
  "translatorUrl": "https://translator.example.com/fetch-data-product",
  "name": "Product name",
  "organizationPublicKeys": [
    {
      "url": "https://example.com/public-key.pub",
      "type": "RsaSignature2018"
    },
    {
      "url": "https://example.com/public-key-2.pub",
      "type": "RsaSignature2018"
    }
  ],
  "description": "This is a product that returns the temperature data for ...",
  "imageUrl": "https://example.com/product-image.png",
  "identityId": "31b5b971-dc50-4c9c-992a-57c0bf016186"
}

```
