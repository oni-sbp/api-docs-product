import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "dataContext": "https://example.com/v1/Context/Data",
  "parameterContext": "https://example.com/v1/Context/Parameter",
  "productCode": "product-1",
  "name": "Product name",
  "translatorUrl": "https://example.com/translator",
  "organizationPublicKeys": [
    {
      "url": "https://example.com/public-key.pub",
      "type": "RsaSignature2018"
    },
    {
      "url": "https://example.com/public-key-2.pub",
      "type": "RsaSignature2018"
    }
  ],
  "imageUrl": "https://example.com/product-image.png",
  "description": "This is a product that returns the temperature data for ...",
  "groupId": "0a52c776-1c9c-42b1-ac03-b64c04abded2"
}

response = requests.post(
    'https://api-sandbox.oftrust.net/products/{version}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
