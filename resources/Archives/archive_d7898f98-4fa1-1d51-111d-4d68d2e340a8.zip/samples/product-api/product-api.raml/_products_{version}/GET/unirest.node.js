const unirest = require("unirest");


unirest
  .get("https://api-sandbox.oftrust.net/products/{version}")
  .query("offset=200&limit=400")
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });