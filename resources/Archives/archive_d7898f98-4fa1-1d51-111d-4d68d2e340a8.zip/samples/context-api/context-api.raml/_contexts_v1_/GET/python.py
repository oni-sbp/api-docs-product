import requests


response = requests.get(
    'https://api-sandbox.oftrust.net/contexts/v1/'
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
