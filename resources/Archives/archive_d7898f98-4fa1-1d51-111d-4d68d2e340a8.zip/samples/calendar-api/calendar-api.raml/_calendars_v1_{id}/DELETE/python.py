import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "type": "Event",
  "title": "April fool's day festivities.",
  "startDate": "2019-04-01T12:00:00+02:00",
  "endDate": "2019-04-01T16:00:00+02:00",
  "repeats": "R5/2008-03-01T13:00:00Z/P1Y2M10DT2H30M",
  "content": "April fool's event, held on the courtyard.",
  "location": "Courtyard at Teststreet 12"
}


response = requests.delete(
    'https://api-sandbox.oftrust.net/calendars/v1/{id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
