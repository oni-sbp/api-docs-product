```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "type": "Event",
  "title": "April fool's day festivities.",
  "startDate": "2019-04-01T12:00:00+02:00",
  "endDate": "2019-04-01T16:00:00+02:00",
  "repeats": "R5/2008-03-01T13:00:00Z/P1Y2M10DT2H30M",
  "content": "April fool's event, held on the courtyard.",
  "location": "Courtyard at Teststreet 12"
}


response = requests.put(
    'https://api-sandbox.oftrust.net/calendars/v1/{id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X PUT \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
   -H "Content-Type: application/json" \
   -d \
"{
  \"type\": \"Event\",
  \"title\": \"April fool's day festivities.\",
  \"startDate\": \"2019-04-01T12:00:00+02:00\",
  \"endDate\": \"2019-04-01T16:00:00+02:00\",
  \"repeats\": \"R5/2008-03-01T13:00:00Z/P1Y2M10DT2H30M\",
  \"content\": \"April fool's event, held on the courtyard.\",
  \"location\": \"Courtyard at Teststreet 12\"
}" "https://api-sandbox.oftrust.net/calendars/v1/{id}"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "type": "Event",
  "title": "April fool's day festivities.",
  "startDate": "2019-04-01T12:00:00+02:00",
  "endDate": "2019-04-01T16:00:00+02:00",
  "repeats": "R5/2008-03-01T13:00:00Z/P1Y2M10DT2H30M",
  "content": "April fool's event, held on the courtyard.",
  "location": "Courtyard at Teststreet 12"
}; 

unirest
  .put("https://api-sandbox.oftrust.net/calendars/v1/{id}")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "@context": "https://standards.lifeengine.io/v1/Context/Calendar",
  "@type": "Event",
  "@id": "c9620d09-cd83-476e-91f5-3f3ea730f4b9",
  "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
  "title": "April's fools day",
  "startDate": "2019-04-01T12:00:00+02:00",
  "endDate": "2019-04-01T16:00:00+02:00",
  "repeats": "R5/2019-04-01T12:00:00+02:00/P1Y",
  "content": "April fool's event, held on the courtyard.",
  "location": "Courtyard at Teststreet 12",
  "cc": [],
  "createdAt": "2019-01-10T12:00:00Z",
  "updatedAt": "2019-01-10T12:00:00Z",
  "createdBy": "58422496-5796-4c47-a4a1-88768ea94ea6"
}


```
