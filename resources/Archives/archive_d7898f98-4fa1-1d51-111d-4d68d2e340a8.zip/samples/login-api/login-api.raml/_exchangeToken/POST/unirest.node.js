const unirest = require("unirest");

const headers = {
    "example": "application/x-www-form-urlencoded",
    "Accept": "application/json",
    "Content-Type": "application/json"
}; 
const body = {}; 

unirest
  .post("https://api-sandbox.oftrust.net/exchangeToken")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });