```python
import requests

headers = {
    "example": "application/x-www-form-urlencoded",
    "Accept": "application/json",
    "Content-Type": "application/json"
}
body = {}

response = requests.post(
    'https://api-sandbox.oftrust.net/exchangeToken',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X POST \
   -H "example: application/x-www-form-urlencoded" \
   -H "Accept: application/json" \
   -H "Content-Type: application/json" \
   -d \
"{}" "https://api-sandbox.oftrust.net/exchangeToken"

```

```javascript
const unirest = require("unirest");

const headers = {
    "example": "application/x-www-form-urlencoded",
    "Accept": "application/json",
    "Content-Type": "application/json"
}; 
const body = {}; 

unirest
  .post("https://api-sandbox.oftrust.net/exchangeToken")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzY29wZSI6bnVsbCwiZXhwIjoxNTQ1MTQzMzY1LCJzdWIiOiIwYzMyYjQ3MC03ZmRmLTQ5MWYtYjA1NS04NmIyMzYxZjljZTkiLCJpc3MiOm51bGwsImF1ZCI6IjdjMDM3MjNjLWJiZWYtNDlkMS1hNmFiLTk2OGYzOGNlODRlNiIsImlhdCI6MTU0NTA1Njk2NS4wODE2Njh9.of5sEZBpzWHqjLd2LPsQZXfS1uQWLOeqdvFtqZtq8BwnCllpebX5MyjSaahOBLXBqyAhPxafEETfMZtyAe1-9P-6imvOTv8JDjw5AbNZelPAAflZHX89AcFCJpKuI603ZqywTTyIqdijVZArkNdEfGeQhJXoSmcDLElUnixw5rJF7FKdtCGjIP4aKazRxfn2DJOOhA1BazCR3xXV42OCgMsdiRYEJ2EhcUdlmA7OT-NjAgzOgS12zfVVEM9swwIVPPc27ewd4rmStJSUYHD2hHaRXQKmJqamJfA5W-vxEJH9G6UW3wwM--ROwYHMHcDfN2HIT-AqojMqitNHZr_AlrTQCpcv-BMA2uwg7DT8MMJ0bLrrdst7Eg_ha4U8iz4CgCTlu9MJEVFUzzLMTnMI8Cc74milBJ6xpHsgJItYjC1e4dVCs_5xxLfy44npg21TOX4Uds4uwLLOhy-gnBAVRzzmCD6nkGmAnHc7Kvck_uw7WHMUeHyMfa1LZoEQhOu0AenymKoHs6gH5anCUwBRAUUdTxXIAwDLod1Q-9Hz3_NBTqiV3Nh1Kn-WswWnA0GPIdKLHt0oI-PAZ0Y1CfL9otucvZtL7UR2qXZjEq8lSX0DVlpJX9ma7RFhcBu4evrTkKSfrdQVitXWiE0q1sSh1CeqlVtnVg6dfGuMKaoY9sA",
    "expires_in": 86400,
    "token_type": "Bearer",
    "scope": "",
    "refresh_token": "T2IlwUE7A66eidXpYXgYIT3ltoLez9"
}


```
