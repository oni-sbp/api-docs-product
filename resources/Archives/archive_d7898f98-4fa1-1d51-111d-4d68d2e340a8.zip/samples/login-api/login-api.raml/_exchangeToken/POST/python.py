import requests

headers = {
    "example": "application/x-www-form-urlencoded",
    "Accept": "application/json",
    "Content-Type": "application/json"
}
body = {}

response = requests.post(
    'https://api-sandbox.oftrust.net/exchangeToken',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
