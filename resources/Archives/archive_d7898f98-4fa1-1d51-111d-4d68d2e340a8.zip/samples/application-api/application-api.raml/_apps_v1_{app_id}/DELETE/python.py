import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "name": "Example Application",
  "description": "Application description",
  "privacyPolicyUrl": "http://example.com/privacy.html",
  "webPageUrl": "http://example.com/application.html",
  "iconUrl": "http://example.com/icon.png",
  "scopes": "",
  "defaultScopes": "",
  "redirectUris": "https://example.com/auth-callback",
  "defaultRedirectUri": "https://example.com/auth-callback"
}

response = requests.delete(
    'https://api-sandbox.oftrust.net/apps/v1/{app_id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
