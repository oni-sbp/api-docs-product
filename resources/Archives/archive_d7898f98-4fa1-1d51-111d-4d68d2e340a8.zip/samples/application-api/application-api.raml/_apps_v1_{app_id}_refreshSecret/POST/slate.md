```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "name": "Example Application",
  "description": "Application description",
  "privacyPolicyUrl": "http://example.com/privacy.html",
  "webPageUrl": "http://example.com/application.html",
  "iconUrl": "http://example.com/icon.png",
  "scopes": "",
  "defaultScopes": "",
  "redirectUris": "https://example.com/auth-callback",
  "defaultRedirectUri": "https://example.com/auth-callback"
}

response = requests.post(
    'https://api-sandbox.oftrust.net/apps/v1/{app_id}/refreshSecret',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X POST \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
 "https://api-sandbox.oftrust.net/apps/v1/{app_id}/refreshSecret"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .post("https://api-sandbox.oftrust.net/apps/v1/{app_id}/refreshSecret")
  .headers(headers)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 201

{
  "clientSecret": "YK45hcnq1D7fsgrvbHkPrIexetnnbqZGPQBV23oVgsA"
}

```
