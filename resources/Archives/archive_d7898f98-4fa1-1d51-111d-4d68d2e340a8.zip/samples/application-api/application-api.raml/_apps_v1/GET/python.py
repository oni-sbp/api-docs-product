import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}

response = requests.get(
    'https://api-sandbox.oftrust.net/apps/v1',
    headers=headers
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
