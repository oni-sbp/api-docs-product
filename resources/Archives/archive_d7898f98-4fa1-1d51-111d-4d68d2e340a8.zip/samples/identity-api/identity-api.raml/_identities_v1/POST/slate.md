```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "type": "Group",
  "data": {
    "name": "Company Oy"
  }
}


response = requests.post(
    'https://api-sandbox.oftrust.net/identities/v1',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X POST \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
   -H "Content-Type: application/json" \
   -d \
"{
  \"context\": \"https://standards.lifeengine.io/v1/Context/Identity/Group\",
  \"type\": \"Group\",
  \"data\": {
    \"name\": \"Company Oy\"
  }
}" "https://api-sandbox.oftrust.net/identities/v1"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "type": "Group",
  "data": {
    "name": "Company Oy"
  }
}; 

unirest
  .post("https://api-sandbox.oftrust.net/identities/v1")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 201

{
  "@context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "@type": "Group",
  "@id": "58dc29ab-d52e-4aab-a228-9b54e001797c",
  "data": {
    "name": "Company Oy"
  },
  "metadata": {
    "createdBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
    "updatedBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
    "createdAt": "2018-02-28T16:41:41.090Z",
    "updatedAt": "2018-02-28T16:41:41.090Z"
  },
  "inLinks": [],
  "outLinks": []
}


```
