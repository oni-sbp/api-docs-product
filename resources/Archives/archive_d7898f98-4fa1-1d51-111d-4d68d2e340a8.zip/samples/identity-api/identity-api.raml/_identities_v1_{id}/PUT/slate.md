```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "type": "Group",
  "data": {
    "name": "Company Oy"
  }
}


response = requests.put(
    'https://api-sandbox.oftrust.net/identities/v1/{id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X PUT \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
   -H "Content-Type: application/json" \
   -d \
"{
  \"context\": \"https://standards.lifeengine.io/v1/Context/Identity/Group\",
  \"type\": \"Group\",
  \"data\": {
    \"name\": \"Company Oy\"
  }
}" "https://api-sandbox.oftrust.net/identities/v1/{id}"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "type": "Group",
  "data": {
    "name": "Company Oy"
  }
}; 

unirest
  .put("https://api-sandbox.oftrust.net/identities/v1/{id}")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "@context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "@type": "Group",
  "@id": "58dc29ab-d52e-4aab-a228-9b54e001797c",
  "data": {
    "name": "Company Oy"
  },
  "metadata": {
    "createdBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
    "updatedBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
    "createdAt": "2018-02-28T16:41:41.090Z",
    "updatedAt": "2018-02-28T16:41:41.090Z"
  },
  "inLinks": [
    {
      "@context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
      "@type": "MemberOf",
      "@id": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "from": "58dc29ab-d52e-4aab-a228-9b54e001797c",
      "to": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "data": {},
      "metadata": {
        "createdBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "updatedBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "createdAt": "2018-02-28T16:41:41.090Z",
        "updatedAt": "2018-02-28T16:41:41.090Z"
      }
    }
  ],
  "outLinks": [
    {
      "@context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
      "@type": "MemberOf",
      "@id": "cb40ce78-d3b3-442a-9db7-66f191698b2a",
      "from": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "to": "58dc29ab-d52e-4aab-a228-9b54e001797c",
      "data": {},
      "metadata": {
        "createdBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "updatedBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "createdAt": "2018-02-28T16:41:41.090Z",
        "updatedAt": "2018-02-28T16:41:41.090Z"
      }
    }
  ]
}


```
