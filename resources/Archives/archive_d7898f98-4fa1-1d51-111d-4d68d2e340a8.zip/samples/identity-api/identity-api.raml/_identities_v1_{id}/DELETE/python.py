import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "type": "Group",
  "data": {
    "name": "Company Oy"
  }
}


response = requests.delete(
    'https://api-sandbox.oftrust.net/identities/v1/{id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
