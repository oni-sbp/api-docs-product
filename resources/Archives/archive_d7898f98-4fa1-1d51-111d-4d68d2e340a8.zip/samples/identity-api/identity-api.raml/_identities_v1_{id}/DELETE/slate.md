```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "context": "https://standards.lifeengine.io/v1/Context/Identity/Group",
  "type": "Group",
  "data": {
    "name": "Company Oy"
  }
}


response = requests.delete(
    'https://api-sandbox.oftrust.net/identities/v1/{id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X DELETE \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
 "https://api-sandbox.oftrust.net/identities/v1/{id}"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .delete("https://api-sandbox.oftrust.net/identities/v1/{id}")
  .headers(headers)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 204

{}

```
