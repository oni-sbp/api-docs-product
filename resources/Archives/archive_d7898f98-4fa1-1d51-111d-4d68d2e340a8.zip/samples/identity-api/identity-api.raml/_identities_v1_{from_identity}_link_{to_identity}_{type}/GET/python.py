import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
  "type": "MemberOf"
}


response = requests.get(
    'https://api-sandbox.oftrust.net/identities/v1/{from_identity}/link/{to_identity}/{type}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
