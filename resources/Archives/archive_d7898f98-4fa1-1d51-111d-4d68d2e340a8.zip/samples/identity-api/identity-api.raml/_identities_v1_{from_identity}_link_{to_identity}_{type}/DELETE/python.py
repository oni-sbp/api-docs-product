import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "context": "https://example.com/contexts/type.jsonld",
  "type": "Owner"
}


response = requests.delete(
    'https://api-sandbox.oftrust.net/identities/v1/{from_identity}/link/{to_identity}/{type}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
