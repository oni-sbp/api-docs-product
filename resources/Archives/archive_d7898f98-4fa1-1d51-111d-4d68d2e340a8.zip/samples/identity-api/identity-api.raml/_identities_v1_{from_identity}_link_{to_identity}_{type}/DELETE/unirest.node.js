const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .delete("https://api-sandbox.oftrust.net/identities/v1/{from_identity}/link/{to_identity}/{type}")
  .headers(headers)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });