import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "context": "https://example.com/contexts/type.jsonld",
  "type": "Owner"
}


response = requests.get(
    'https://api-sandbox.oftrust.net/identities/v1/{id}/links',
    params='type=%2Fidentities%2F%7Bversion%7D%2F%7Bid%7D%2Flinks%3Ftype%3DOwner',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
