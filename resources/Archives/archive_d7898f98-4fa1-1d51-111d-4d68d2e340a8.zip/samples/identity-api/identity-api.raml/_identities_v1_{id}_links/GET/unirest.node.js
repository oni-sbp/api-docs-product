const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .get("https://api-sandbox.oftrust.net/identities/v1/{id}/links")
  .headers(headers)
  .query("type=%2Fidentities%2F%7Bversion%7D%2F%7Bid%7D%2Flinks%3Ftype%3DOwner")
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });