```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "context": "https://example.com/contexts/type.jsonld",
  "type": "Owner"
}


response = requests.get(
    'https://api-sandbox.oftrust.net/identities/v1/{id}/links',
    params='type=%2Fidentities%2F%7Bversion%7D%2F%7Bid%7D%2Flinks%3Ftype%3DOwner',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X GET \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
 "https://api-sandbox.oftrust.net/identities/v1/{id}/links?type=%2Fidentities%2F%7Bversion%7D%2F%7Bid%7D%2Flinks%3Ftype%3DOwner"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .get("https://api-sandbox.oftrust.net/identities/v1/{id}/links")
  .headers(headers)
  .query("type=%2Fidentities%2F%7Bversion%7D%2F%7Bid%7D%2Flinks%3Ftype%3DOwner")
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "@context": "https://schema.org/",
  "@type": "collection",
  "ItemList": [
    {
      "@context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
      "@type": "MemberOf",
      "@id": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "from": "58dc29ab-d52e-4aab-a228-9b54e001797c",
      "to": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "data": {},
      "metadata": {
        "createdBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "updatedBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "createdAt": "2018-02-28T16:41:41.090Z",
        "updatedAt": "2018-02-28T16:41:41.090Z"
      }
    },
    {
      "@context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
      "@type": "MemberOf",
      "@id": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "from": "58dc29ab-d52e-4aab-a228-9b54e001797c",
      "to": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
      "data": {},
      "metadata": {
        "createdBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "updatedBy": "cf0862f6-3f4f-498f-97f1-fbe8b5734448",
        "createdAt": "2018-02-28T16:41:41.090Z",
        "updatedAt": "2018-02-28T16:41:41.090Z"
      }
    }
  ]
}


```
