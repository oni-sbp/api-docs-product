const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .get("https://api-sandbox.oftrust.net/identities/v1/dataDiscovery")
  .headers(headers)
  .query("fromId=fc3bced4-a132-4293-9240-4d0f02277e2e&linkContext=&identityContext=https%3A%2F%2Fstandards.oftrust.net%2Fv1%2FContext%2FIdentity%2FDevice%2FSensor%2F&linkDirection=IN&maxDepth=2&offset=10&limit=20")
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });