const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
  "type": "MemberOf"
}; 

unirest
  .post("https://api-sandbox.oftrust.net/identities/v1/{from_identity}/link/{to_identity}")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });