import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "context": "https://standards.lifeengine.io/v1/Context/Link/Role/MemberOf",
  "type": "MemberOf"
}


response = requests.post(
    'https://api-sandbox.oftrust.net/identities/v1/{from_identity}/link/{to_identity}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
