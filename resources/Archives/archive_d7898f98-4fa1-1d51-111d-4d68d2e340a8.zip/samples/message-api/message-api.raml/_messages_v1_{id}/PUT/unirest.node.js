const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!"
}; 

unirest
  .put("https://api-sandbox.oftrust.net/messages/v1/{id}")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });