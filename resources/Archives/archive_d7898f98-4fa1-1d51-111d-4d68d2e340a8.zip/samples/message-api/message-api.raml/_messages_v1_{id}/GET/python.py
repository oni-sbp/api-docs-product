import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!",
  "cc": []
}


response = requests.get(
    'https://api-sandbox.oftrust.net/messages/v1/{id}',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
