const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!",
  "cc": []
}; 

unirest
  .post("https://api-sandbox.oftrust.net/messages/v1")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });