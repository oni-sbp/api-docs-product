```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}
body = {
  "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!",
  "cc": []
}


response = requests.post(
    'https://api-sandbox.oftrust.net/messages/v1',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X POST \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
   -H "Content-Type: application/json" \
   -d \
"{
  \"toIdentity\": \"0920a84a-1548-4644-b95d-e3f80e1b9ca6\",
  \"subject\": \"Go to the grocery store\",
  \"content\": \"Remember to buy milk!\",
  \"cc\": []
}" "https://api-sandbox.oftrust.net/messages/v1"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>",
    "Content-Type": "application/json"
}; 
const body = {
  "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!",
  "cc": []
}; 

unirest
  .post("https://api-sandbox.oftrust.net/messages/v1")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 201

{
  "@context": "https://standards.lifeengine.io/v1/Context/Message",
  "@type": "Message",
  "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!",
  "cc": [],
  "createdAt": "2019-01-10T12:00:00Z",
  "updatedAt": "2019-01-10T12:00:00Z",
  "createdBy": "58422496-5796-4c47-a4a1-88768ea94ea6"
}


```
