```python
import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!"
}


response = requests.get(
    'https://api-sandbox.oftrust.net/messages/v1/{toIdentity}/list',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X GET \
   -H "Authorization: Bearer <ACCESS_TOKEN>" \
 "https://api-sandbox.oftrust.net/messages/v1/{toIdentity}/list"

```

```javascript
const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .get("https://api-sandbox.oftrust.net/messages/v1/{toIdentity}/list")
  .headers(headers)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "@context": "https://schema.org/",
  "@type": "collection",
  "ItemList": [
    {
      "@context": "https://standards.lifeengine.io/v1/Context/Message",
      "@type": "Message",
      "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
      "subject": "Go to the grocery store",
      "content": "Remember to buy milk!",
      "cc": [
        "323bde80-4cc2-472e-bb77-e6a3e95a1253",
        "0827e9c3-9664-479f-b0ec-956a35d72e4b"
      ],
      "createdAt": "2019-01-10T12:00:00Z",
      "updatedAt": "2019-01-10T12:00:00Z",
      "createdBy": "58422496-5796-4c47-a4a1-88768ea94ea6"
    },
    {
      "@context": "https://standards.lifeengine.io/v1/Context/Message",
      "@type": "Message",
      "toIdentity": "0920a84a-1548-4644-b95d-e3f80e1b9ca6",
      "subject": "You forgot the milk",
      "content": "...",
      "cc": [],
      "createdAt": "2019-01-10T12:00:00Z",
      "updatedAt": "2019-01-10T12:00:00Z",
      "createdBy": "58422496-5796-4c47-a4a1-88768ea94ea6"
    }
  ]
}


```
