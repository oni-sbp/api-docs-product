const unirest = require("unirest");

const headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}; 

unirest
  .get("https://api-sandbox.oftrust.net/messages/v1/{toIdentity}/list")
  .headers(headers)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });