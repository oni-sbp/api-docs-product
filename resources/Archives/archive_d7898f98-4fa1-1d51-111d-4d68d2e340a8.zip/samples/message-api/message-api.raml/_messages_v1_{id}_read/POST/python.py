import requests

headers = {
    "Authorization": "Bearer <ACCESS_TOKEN>"
}
body = {
  "subject": "Go to the grocery store",
  "content": "Remember to buy milk!"
}


response = requests.post(
    'https://api-sandbox.oftrust.net/messages/v1/{id}/read',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
