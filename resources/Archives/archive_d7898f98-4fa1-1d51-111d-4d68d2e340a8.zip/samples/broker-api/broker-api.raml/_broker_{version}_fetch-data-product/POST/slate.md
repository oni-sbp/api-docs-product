```python
import requests

headers = {
    "X-Pot-Signature": "Ioma1gqOVFUBrXiziWS....CLqBG4vFozG3YgzPzillNip0=",
    "X-App-Token": "eyJ0eXAiOiJJV1QiLcJhbgciOiJSUzI1NiJ9.eyJzY29w...VXs5fff",
    "X-User-Token": "eyJ0eXAIOijKV1QiLcJGbGciOiJSUzI1NiJ9.eyJzY29w...DVs5aaf",
    "Content-Type": "application/json"
}
body = {
  "timestamp": "2018-11-01T12:00:00+00:00",
  "productCode": "product-1",
  "parameters": {
    "param-1": "Value",
    "param-2": "Value"
  }
}


response = requests.post(
    'https://api-sandbox.oftrust.net/broker/{version}/fetch-data-product',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})

```

```shell
curl -i -X POST \
   -H "X-Pot-Signature: Ioma1gqOVFUBrXiziWS....CLqBG4vFozG3YgzPzillNip0=" \
   -H "X-App-Token: eyJ0eXAiOiJJV1QiLcJhbgciOiJSUzI1NiJ9.eyJzY29w...VXs5fff" \
   -H "X-User-Token: eyJ0eXAIOijKV1QiLcJGbGciOiJSUzI1NiJ9.eyJzY29w...DVs5aaf" \
   -H "Content-Type: application/json" \
   -d \
"{
  \"timestamp\": \"2018-11-01T12:00:00+00:00\",
  \"productCode\": \"product-1\",
  \"parameters\": {
    \"param-1\": \"Value\",
    \"param-2\": \"Value\"
  }
}" "https://api-sandbox.oftrust.net/broker/{version}/fetch-data-product"

```

```javascript
const unirest = require("unirest");

const headers = {
    "X-Pot-Signature": "Ioma1gqOVFUBrXiziWS....CLqBG4vFozG3YgzPzillNip0=",
    "X-App-Token": "eyJ0eXAiOiJJV1QiLcJhbgciOiJSUzI1NiJ9.eyJzY29w...VXs5fff",
    "X-User-Token": "eyJ0eXAIOijKV1QiLcJGbGciOiJSUzI1NiJ9.eyJzY29w...DVs5aaf",
    "Content-Type": "application/json"
}; 
const body = {
  "timestamp": "2018-11-01T12:00:00+00:00",
  "productCode": "product-1",
  "parameters": {
    "param-1": "Value",
    "param-2": "Value"
  }
}; 

unirest
  .post("https://api-sandbox.oftrust.net/broker/{version}/fetch-data-product")
  .headers(headers)
  .send(body)
  .then(({ raw_body, status, code }) => {
    // output response to console as JSON
    console.log(JSON.stringify({ raw_body, status, code }, null, 4));
  });

```

```java
System.out.println("Java example missing. Why not contribute one for us?");
```

> The above example should return `JSON` structured like this:

```json
The above example should return JSON structured like this:

HTTP/1.0 200

{
  "@context": "<context url>",
  "data": {
    <response from translator>
  },
  "signature": {
    "type": "<signature type>",
    "created": "<RFC3339>",
    "creator": "<public key URL>",
    "signatureValue": "..."
  }
}


```
