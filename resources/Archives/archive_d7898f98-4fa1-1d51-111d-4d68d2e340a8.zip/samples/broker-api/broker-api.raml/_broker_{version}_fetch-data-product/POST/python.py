import requests

headers = {
    "X-Pot-Signature": "Ioma1gqOVFUBrXiziWS....CLqBG4vFozG3YgzPzillNip0=",
    "X-App-Token": "eyJ0eXAiOiJJV1QiLcJhbgciOiJSUzI1NiJ9.eyJzY29w...VXs5fff",
    "X-User-Token": "eyJ0eXAIOijKV1QiLcJGbGciOiJSUzI1NiJ9.eyJzY29w...DVs5aaf",
    "Content-Type": "application/json"
}
body = {
  "timestamp": "2018-11-01T12:00:00+00:00",
  "productCode": "product-1",
  "parameters": {
    "param-1": "Value",
    "param-2": "Value"
  }
}


response = requests.post(
    'https://api-sandbox.oftrust.net/broker/{version}/fetch-data-product',
    headers=headers,
    json=body
)

print({
    'raw_body': response.text,
    'status': response.status_code,
    'code': response.status_code
})
